from js import document, console
from pyodide.ffi import create_proxy
import ast, math, re

history = []
MAX_HISTORY = 200
selected_history_index = None
angle_unit = 'deg'

# --- Evaluátor ---
ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)
ALLOWED_UNARY = (ast.UAdd, ast.USub)

def eval_ast(node):
    if isinstance(node, ast.Expression): return eval_ast(node.body)
    if isinstance(node, ast.BinOp):
        left, right = eval_ast(node.left), eval_ast(node.right)
        if isinstance(node.op, ast.Add): return left+right
        if isinstance(node.op, ast.Sub): return left-right
        if isinstance(node.op, ast.Mult): return left*right
        if isinstance(node.op, ast.Div):
            if right==0: raise ZeroDivisionError()
            return left/right
        if isinstance(node.op, ast.Pow): return left**right
        raise ValueError("Nepovolená binární operace")
    if isinstance(node, ast.UnaryOp):
        operand = eval_ast(node.operand)
        if isinstance(node.op, ast.UAdd): return +operand
        if isinstance(node.op, ast.USub): return -operand
        raise ValueError("Nepovolený unární operátor")
    if isinstance(node, ast.Constant):
        if isinstance(node.value,(int,float)): return node.value
        raise ValueError("Nepovolená konstanta")
    raise ValueError(f"Nepovolený AST uzel {type(node)}")

def safe_eval(expr: str):
    global angle_unit
    expr = expr.replace('÷','/').replace('×','*').replace('−','-').replace('^','**')
    expr = re.sub(r'(\d+)%', r'(\1/100)', expr)
    allowed_names = {
        'sin': lambda x: math.sin(math.radians(x) if angle_unit=='deg' else x),
        'cos': lambda x: math.cos(math.radians(x) if angle_unit=='deg' else x),
        'tan': lambda x: math.tan(math.radians(x) if angle_unit=='deg' else x),
        'log': math.log,
        'exp': math.exp,
        'sqrt': math.sqrt
    }
    code = compile(expr, "<string>", "eval", flags=ast.PyCF_ONLY_AST)
    for node in ast.walk(code):
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in allowed_names:
                raise ValueError(f"Neplatná funkce {getattr(node.func,'id',node.func)}")
        elif isinstance(node, ast.BinOp) and not isinstance(node.op, ALLOWED_BINOPS):
            raise ValueError("Nepovolený binární operátor")
        elif isinstance(node, ast.UnaryOp) and not isinstance(node.op, ALLOWED_UNARY):
            raise ValueError("Nepovolený unární operátor")
        elif isinstance(node, ast.Name) and node.id not in allowed_names:
            raise ValueError(f"Nepovolená proměnná {node.id}")
    return eval(compile(code, "<string>", "eval"), {"__builtins__": None}, allowed_names)

# --- UI ---
input_el = document.getElementById('display')
history_list_el = document.getElementById('history-list')
btn_equals = document.getElementById('btn-equals')
btn_clear = document.getElementById('btn-clear')
btn_back = document.getElementById('btn-back')
btn_copy_op = document.getElementById('btn-copy-op')
btn_copy_res = document.getElementById('btn-copy-res')
angle_unit_el = document.getElementById('angle-unit')
convert_base_el = document.getElementById('convert-base')
btn_convert = document.getElementById('btn-convert')
buttons = document.querySelectorAll('#buttons button')

def format_result(v):
    if isinstance(v,float) and v.is_integer(): return str(int(v))
    return str(v)

def render_history():
    history_list_el.innerHTML = ''
    for i,item in enumerate(reversed(history)):
        idx = len(history)-1-i
        div = document.createElement('div'); div.className='his-item'
        left = document.createElement('div'); left.innerHTML=f"<strong>{item['expr']}</strong> = {format_result(item['result'])}"
        right = document.createElement('div')
        btn_op = document.createElement('button'); btn_op.textContent='Vložit operaci'
        btn_res = document.createElement('button'); btn_res.textContent='Vložit výsledek'
        def make_op(ix):
            def _ev(ev):
                global selected_history_index
                selected_history_index=ix
                input_el.value = history[ix]['expr']
            return _ev
        def make_res(ix):
            def _ev(ev):
                global selected_history_index
                selected_history_index=ix
                input_el.value = str(history[ix]['result'])
            return _ev
        btn_op.addEventListener('click', create_proxy(make_op(idx)))
        btn_res.addEventListener('click', create_proxy(make_res(idx)))
        right.appendChild(btn_op)
        right.appendChild(btn_res)
        div.appendChild(left)
        div.appendChild(right)
        history_list_el.appendChild(div)

def append_to_input(s):
    input_el.value = (input_el.value or '') + s

for b in buttons:
    val = b.getAttribute('data-val')
    if val is not None:
        def make_handler(v):
            def _ev(evt):
                append_to_input(v)
            return _ev
        b.addEventListener('click', create_proxy(make_handler(val)))

btn_clear.addEventListener('click', create_proxy(lambda ev:setattr(input_el,'value','')))
btn_back.addEventListener('click', create_proxy(lambda ev:setattr(input_el,'value',(input_el.value or '')[:-1])))

def calculate(ev):
    try:
        res = safe_eval(input_el.value)
    except Exception as e:
        input_el.value = ''
        console.log(f"Chyba: {e}")
        return
    history.append({'expr':input_el.value,'result':res})
    if len(history)>MAX_HISTORY: history.pop(0)
    render_history()
    input_el.value = format_result(res)

btn_equals.addEventListener('click', create_proxy(calculate))

def copy_op(ev):
    global selected_history_index
    if selected_history_index is None: return
    input_el.value = history[selected_history_index]['expr']
btn_copy_op.addEventListener('click', create_proxy(copy_op))

def copy_res(ev):
    global selected_history_index
    if selected_history_index is None: return
    input_el.value = str(history[selected_history_index]['result'])
btn_copy_res.addEventListener('click', create_proxy(copy_res))

# --- Převody ---
def convert(ev):
    try:
        val = float(input_el.value)
    except:
        console.log("Neplatný vstup")
        return
    base = int(convert_base_el.value)
    if base==10: input_el.value=str(val)
    elif base==2: input_el.value=bin(int(val))
    elif base==8: input_el.value=oct(int(val))
    elif base==16: input_el.value=hex(int(val))

btn_convert.addEventListener('click', create_proxy(convert))
angle_unit_el.addEventListener('change', create_proxy(lambda ev:setattr(globals(),'angle_unit',angle_unit_el.value)))
